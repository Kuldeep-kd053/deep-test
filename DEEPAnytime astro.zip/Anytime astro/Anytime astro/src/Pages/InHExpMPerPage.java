package Pages;

import Test.LaunchBrowserPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;
import java.util.List;

public class InHExpMPerPage extends
        LaunchBrowserPage {
    static WebDriver driver;
    public InHExpMPerPage(WebDriver driver) {
        this.driver = driver;
    }

    public static String InHouseExpert_name = "user_test@tafmail.com";
    public static String InHouseExpert_pass = "0";
    public static String[] in_house_expert_list = {"Home", "Experts", "Expert Profiles", "Registrations", "Chat Reviews",
            "Chat Report", "Attendance Report", "Account deletion Request", "Psychic Calls", "Chat Invite Summary",
            "Customer Spam Report", "Missed Chat Report", "Psychic Profile Review", "Expert Performance",
            "Notice Board", "Notice Board List", "Occasion", "Welcome Message Request", "Update Bank-Detail",
            "Bank-Detail List", "Expert Insights Summary", "Live Session Report"};

    @FindBy(how = How.XPATH,using = "//li[@class='select2-results__option']")
    public static List<WebElement> list_of_experts;
    @FindBy(how = How.XPATH,using = "//li[@class='select2-results__option']")
    public static WebElement list_of_expert;

    @FindBy(how = How.XPATH, using = "(//span[@class='select2-selection select2-selection--single'])[1]")
    public static WebElement Expert_dropdown;
    // click on psychic call



    public static void select_drop_down(){



    }


    }


