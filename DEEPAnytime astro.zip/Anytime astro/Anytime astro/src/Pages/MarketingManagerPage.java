package Pages;

import org.openqa.selenium.WebDriver;

public class MarketingManagerPage {
    WebDriver driver;
    public MarketingManagerPage(WebDriver driver) {
        this.driver = driver;
    }
}
