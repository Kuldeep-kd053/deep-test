package Pages;

import Test.LaunchBrowserPage;
import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PujaAdminPage extends LaunchBrowserPage {


    @FindBy(how = How.XPATH, using = "//div[@class='col-md-2']//span[contains(text(),'Puja Purchase')]")
    public static
    WebElement puja_Purchase;

    @FindBy(how = How.XPATH, using = "//li[@class='list-inline-item']//input[@type='checkbox']")
    public static WebElement test_CheckBox;
    @FindBy(how = How.ID, using = "search")
    public static WebElement search;


    public static void puja_purchase(){
        puja_Purchase.click();
        test_CheckBox.click();
        search.click();
    }

    public static void handleAlert(){
        if(isAlertPresent()){
            Alert alert = driver.switchTo().alert();
            System.out.println(alert.getText());
            alert.accept();
        }
    }
    public static boolean isAlertPresent(){
        try{
            driver.switchTo().alert();
            return true;
        }catch(NoAlertPresentException ex){
            return false;
        }
    }
}
