package Pages;

import org.openqa.selenium.WebDriver;

public class OnBoardingManagerPage {
    WebDriver driver;
    public OnBoardingManagerPage(WebDriver driver) {
        this.driver = driver;
    }
}
