package Pages;


import com.sun.jdi.ThreadGroupReference;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Set;
import static Test.LaunchBrowserPage.driver;


public class PujaPurchasePage {
    public static String Puja_URL_test = "https://otest.anytimeastro.com/puja/products/";

    public static String Puja_Live_URL = "https://www.anytimeastro.com/puja/products/";
    @FindBy(how = How.XPATH, using = "//div[contains(text(),'Choose Options')]")
    public static List<WebElement> choose_option;
    @FindBy(how = How.XPATH, using = "//div[contains(text(),'Add to Cart')]")
    public static List<WebElement> list_add_to_cart;

    @FindBy(how = How.ID, using = "paynow")
    public static WebElement paynow;
    @FindBy(how = How.ID, using = "addcart")
    public static WebElement add_to_cart;
    @FindBy(how = How.XPATH, using = "//div[@class='offcanvas-bottom-body']//a")
    public static WebElement check_out;
    @FindBy(how = How.ID, using = "fname")
    public static WebElement name;
    @FindBy(how = How.ID, using = "lname")
    public static WebElement last_name;

    @FindBy(how = How.NAME, using = "phone")
    public static WebElement Phone;
    @FindBy(how = How.ID, using = "Email")
    public static WebElement email;
    @FindBy(how = How.ID, using = "INR")
    public static WebElement inr;
    @FindBy(how = How.ID, using = "USD")
    public static WebElement USD;

    @FindBy(how = How.XPATH, using = "//div[@class='product-detail bg-white py-4']")
    public static WebElement puja_details_page;

    @FindBy(how = How.XPATH, using = "//span[contains(text(),'Next')]")
    public static WebElement next;
    @FindBy(how = How.XPATH, using = "(//div[@class='flex items-center justify-between'])[2]")
    public static WebElement phone_pe;
    @FindBy(how = How.XPATH, using = "//div[@id='modal-inner']//div[@class='svelte-30hv15']")
    public static WebElement click_on_wallet;
    @FindBy(how = How.XPATH, using = "//p[@class='fw-bold mb-0 text-black']")
    public static List<WebElement> add_choose;
    @FindBy(how = How.XPATH, using = "//div[@role='alert']")
    public static WebElement alert_message;

    @FindBy(how = How.XPATH, using = "(//div[@data-value='wallet'])[2]")
    public static WebElement razorpay_wallet;
    @FindBy(how = How.XPATH, using = "  (//form[@method='post']//button)[1]")
    public static WebElement success_button;

    @FindBy(how = How.XPATH, using = "(//p[@class='font-14']//b)[1]")
    public static WebElement pay_id;


    public static List<String> all_elements_text = new ArrayList<>();
    // admin panel
    @FindBy(how = How.NAME, using = "Email")
    public static WebElement admin_username;
    @FindBy(how = How.NAME, using = "Passwrd")
    public static WebElement admin_pass;
    @FindBy(how = How.XPATH, using = "//button[contains(text(),'Sign In')]")
    public static WebElement admin_sign_in;
    @FindBy(how = How.XPATH, using = "(//span[@class='text-blue'])[3]")
    public static WebElement admin_get_order_id;
    @FindBy(how = How.XPATH, using = "(//tr[@role='row']//td)[5]")
    public static List<WebElement> user_mail_on_admin;
    @FindBy(how = How.XPATH, using = "//tbody//tr[@role='row'']")
    public static List<WebElement> order_list_admin;
    @FindBy(how = How.ID, using = "OrderSearch")
    public static WebElement Order_search;
    @FindBy(how = How.ID, using = "btnSearch")
    public static WebElement button_search_button;


    @FindBy(how = How.ID, using = "PujaTypeId")
    public static WebElement category_type_drop_down;
    @FindBy(how = How.ID, using = "CurrencyId")
    public static WebElement currency_dropdown;
    @FindBy(how = How.ID, using = "baseAmt")
    public static WebElement base_amount;
    @FindBy(how = How.ID, using = "netAmt")
    public static WebElement net_amount;
    @FindBy(how = How.ID, using = "discount")
    public static WebElement discount_amount;


    @FindBy(how = How.ID, using = "item_master_name")
    public static WebElement item_master_name;
    @FindBy(how = How.ID, using = "btnSubmit")
    public static WebElement add;
    @FindBy(how = How.ID, using = "imgUrl")
    public static WebElement choose_image;

    @FindBy(how = How.XPATH, using = "//span[contains(text(),'Master')]")
    public static WebElement master;
    @FindBy(how = How.XPATH, using = "//a[contains(text(),' Item Master')]")
    public static WebElement item_master;
    @FindBy(how = How.ID, using = "CategoryId")
    public static WebElement select_category;
    @FindBy(how = How.ID, using = "item_master_name")
    public static WebElement Enter_Item_Master_Name;


    @FindBy(how = How.XPATH, using = "//input[@type='search']")
    public static WebElement puja_search;

    @FindBy(how = How.XPATH, using = "//a[contains(text(),'View/Edit Variants')]")
    public static WebElement view_edit_variant;
    @FindBy(how = How.XPATH, using = "//a[contains(text(),'View/Edit Detail')]")
    public static WebElement view_edit_detail;


    @FindBy(how = How.XPATH, using = "//input[@value='Edit']")
    public static WebElement edit_item_variant;

    @FindBy(how = How.ID, using = "title")
    public static WebElement puja_title;
    @FindBy(how = How.ID, using = "Badgedescription")
    public static WebElement badge_description;
    @FindBy(how = How.CLASS_NAME, using = "(note-editable")
    public static WebElement short_description;
    @FindBy(how = How.CLASS_NAME, using = "note-editable")
    public static WebElement long_description;
    @FindBy(how = How.CLASS_NAME, using = "note-editable")
    public static WebElement mobile_description;


    public static String puja_image_path = "/C://Users//kuldeep//Downloads//happy-ganesh-chaturthi-traditional-greeting-card-background//2642.jpg";


    @FindBy(how = How.XPATH, using = " //i[@class='fa fa-book']")
    public static WebElement admin_report_option;
    @FindBy(how = How.XPATH, using = "//ul[@class='treeview-menu menu-open']")
    public static WebElement admin_order_list;
    public static String Puja_admin_URL = "https://pujatestadmin.anytimeastro.com/";
    //view/ edit price
    @FindBy(how = How.XPATH, using = "//a[contains(text(),'View/Edit Price')]")
    public static WebElement view_edit_price;
    static List<String> all_puja_list = new ArrayList<>();

    public static void navigate_checkout() {
        try {
            add_to_cart.click();
        } catch (Exception e) {
            e.printStackTrace();
        }
        check_out.click();
    }

    public static void checkout_user_details(String fname, String lname, String number, String mail) {
        name.sendKeys(fname);
        last_name.sendKeys(lname);
        Phone.sendKeys(number);
        email.sendKeys(mail);
    }

    public static void all_puja_name_with_options() {
        for (WebElement element : choose_option) {
            all_elements_text.add(element.getText());
        }
        for (WebElement addtocart : list_add_to_cart) {
            all_elements_text.add(addtocart.getText());
        }
    }

    public static void all_puja_list() throws InterruptedException {
        for (WebElement webElement : add_choose) {
            all_puja_list.add(webElement.getText());
        }
        int puja_number = all_puja_list.size();
        if (puja_number % 50 == 0) {
            try {
                WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(2)); // Timeout after 10 seconds
                wait.until(ExpectedConditions.elementToBeClickable(next));
                next.click();
            } catch (ElementNotInteractableException e) {
                //System.out.println("Element is not interactable: " + e.getMessage());
                //Perform alternative action, such as scrolling the page
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
                next.click();
                // recursive method call
                all_puja_list();
            }
        }
    }

    public static void select_puja() throws InterruptedException {
        int puja_number3 = Math.min(50, add_choose.size());
        Random random = new Random();
        int randomProduct = random.nextInt(puja_number3);
        WebElement randomElement = add_choose.get(randomProduct);

        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(2)); // Timeout after 10 seconds
            wait.until(ExpectedConditions.elementToBeClickable(randomElement));
            randomElement.click();
        } catch (ElementNotInteractableException e) {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
            // click on element
            randomElement.click();
        }

        try {
            puja_details_page.isDisplayed();
        } catch (NoSuchElementException e) {
            System.out.println("puja page doesn't open, again trying to open it" + e.getMessage());
            select_puja();
        } catch (ElementClickInterceptedException e) {
            System.out.println("puja page doesn't open, again trying to open it" + e.getMessage());
        }
    }

    public static void admin_login() {
        driver.get(Puja_admin_URL);
        admin_username.sendKeys("admin@gmail.com");
        admin_pass.sendKeys("123456");
        admin_sign_in.click();
    }

    public static void puja_report() {
        admin_report_option.click();
        admin_order_list.click();
        admin_get_order_id.getText();
    }

    public static void switch_window() {
        try {
            // Find the iframe containing the Razorpay popup
            WebElement iframe = driver.findElement(By.xpath("//iframe[@class='razorpay-checkout-frame']"));
            // Switch to the iframe(razor pay tab)
            driver.switchTo().frame(iframe);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void razorpayoption() {
        for (int i = 0; i < 3; i++) {
            try {
                Thread.sleep(1000);
                //click_on_wallet.click();
                //phone_pe.click();
                razorpay_wallet.click();
                break; // break loop if element found
            } catch (NoSuchElementException | InterruptedException e) {
                System.out.println("Attempt " + (i + 1) + ": Element not found yet, retrying...");
            }
        }
    }

    public static void switch_success_Page_main_window() {
        Set<String> windowHandles = driver.getWindowHandles();
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());

        // Switch to the new window
        for (String windowHandle : windowHandles) {
            if (!windowHandle.equals(driver.getWindowHandle())) {
                // switch to success/failed page
                driver.switchTo().window(windowHandle);
            }
        }
        // try up to 3 times go find elements
        for (int j = 0; j < 3; j++) {
            try {
                Thread.sleep(2000);
                success_button.click();
                break; // break loop if element found
            } catch (NoSuchElementException | InterruptedException e) {
                System.out.println("Attempt " + (j + 1) + ": Element not found yet, retrying...");
                // You can optionally wait a bit before retrying
                try {
                    Thread.sleep(2000); // Wait for 2 seconds before retrying
                } catch (InterruptedException ignored) {
                }
            }
        }
        // switch back to main window
        driver.switchTo().window(tabs.get(0));
        // try up to 3 times go find elements
    }

    public static void get_payment_id_success_page() {
        for (int k = 0; k < 3; k++) {
            try {
                System.out.println("Payment ID: " + pay_id.getText());
                break; // break loop if element found
            } catch (NoSuchElementException e) {
                System.out.println("Attempt " + (k + 1) + ": Element not found yet, retrying...");
            }
        }
    }

    public static void item_master_list() {
        master.click();
        item_master.click();
    }

    public static void Select_Puja_Type(String type) {
        Select dropdown = new Select(category_type_drop_down);
        // Select an option by visible text
        dropdown.selectByVisibleText(type);
    }

    public static void select_currency_type() throws InterruptedException {
        Select dropdown = new Select(currency_dropdown);
        // Select an option by visible text
        List<WebElement> options = dropdown.getOptions();
        // Iterate through each option and select it one by one
        for (int i = 1; i < options.size(); i++) {
            WebElement option = options.get(i);
            // Select the option
            dropdown.selectByVisibleText(option.getText());
            System.out.println("dropdown currency name: " + i + " " + option.getText());
            base_amount.sendKeys("100");
            discount_amount.sendKeys("10");
            net_amount.sendKeys("50");
            add.click();
        }
        Thread.sleep(3000);
    }


    public static void select_category(String category_name) {
        Select dropdown1 = new Select(select_category);
        // Select an option by visible text
        dropdown1.selectByVisibleText(category_name);
    }

    public static void enter_item_master_name(String item_name) {
        Enter_Item_Master_Name.sendKeys(item_name);
    }

    public static void create_puja() {
        admin_login();
        item_master_list();
        Select_Puja_Type("Individual");
        select_category("Deep Test Category");
        enter_item_master_name("wow");
        add.click();
    }

    public static void search_puja(String puja_name) {
        puja_search.sendKeys(puja_name);

    }

    public static void edit_puja_variant() throws InterruptedException {
        search_puja("wow");
        view_edit_variant.click();
        view_edit_detail.click();
        Thread.sleep(2000);
        puja_title.click();
        Thread.sleep(2000);
        puja_title.sendKeys(" Ganpati and Mahadev puja");
        badge_description.sendKeys(" Ganpati and Mahadev puja");
        Thread.sleep(10000);

        try {
            String description = "Your content goes here";  // Replace with data.result.description
            // Locate the Summernote editor (if necessary)
            WebElement short_description = driver.findElement(By.xpath("(//div[@class='note-editable'])[1]"));
            // Use JavascriptExecutor to execute the jQuery code
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("$('#longDescription1').summernote('code', arguments[0]);", description);
            //short_description.click();
            short_description.sendKeys(" Experienced Pandits");
            // driver.switchTo().defaultContent();
        } catch (java.util.NoSuchElementException e) {
            System.out.println(" Element not found.");
        }

        try {
            String description = "Your content goes here";  // Replace with data.result.description
            // Locate the Summernote editor (if necessary)
            WebElement long_description = driver.findElement(By.xpath("(//div[@class='note-editable'])[2]"));
            // Use JavascriptExecutor to execute the jQuery code
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("$('#longDescription1').summernote('code', arguments[0]);", description);
            //short_description.click();
            long_description.click();
            long_description.sendKeys(" Performing Aparajita Puja is considered auspicious ");
        } catch (java.util.NoSuchElementException e) {
            System.out.println("Element not found.");
        }

        try {
            String description = "Your content goes here";  // Replace with data.result.description
            // Locate the Summernote editor (if necessary)
            WebElement mobile_description = driver.findElement(By.xpath("(//div[@class='note-editable'])[3]"));
            // Use JavascriptExecutor to execute the jQuery code
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("$('#longDescription1').summernote('code', arguments[0]);", description);
            //short_description.click();
            mobile_description.sendKeys(" Performing Aparajita Puja ");
        } catch (java.util.NoSuchElementException e) {
            System.out.println("element not found");

        }
        Thread.sleep(2000);
        add.click();
    }

    public static void item_variant_price() throws InterruptedException {
        view_edit_price.click();
        select_currency_type();
    }
}
