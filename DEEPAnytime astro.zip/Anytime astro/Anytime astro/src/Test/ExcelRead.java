package Test;


import Pages.PujaPurchasePage;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.NoSuchElementException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.IOException;

import static Pages.PujaPurchasePage.*;


public class ExcelRead extends LaunchBrowserPage {
    @Test
    public static  void test_test() throws IOException, InterruptedException {
        PujaPurchasePage pujaPurchasePage = PageFactory.initElements(driver, PujaPurchasePage.class);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        admin_login();
        item_master_list();
        search_puja("Jai Bhole Puja");
        view_edit_variant.click();
        item_variant_price();
        System.out.println("work done upto yet wow");
        String filePath = "D://automation test.xlsx";
//        FileInputStream excelFile = new FileInputStream(filePath);
//        Workbook workbook = new XSSFWorkbook(excelFile);  // For .xlsx format, use XSSFWorkbook
//        // Get the first sheet from the workbook
//        Sheet sheet = workbook.getSheetAt(1);  // Replace 0 with the index of your sheet
//        // Iterate through rows and columns
//        for (Row row : sheet) {
//            for (Cell cell : row) {
//                // Extract cell value
//                System.out.print(cell.toString() + "\t");
//            }
//            System.out.println("wow");
//        }
//        // Close workbook and file stream
//        workbook.close();
//        excelFile.close();
    }
}
