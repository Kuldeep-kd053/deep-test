package Test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import static Pages.InHExpMPerPage.in_house_expert_list;
import static Pages.InHExpMPerPage.*;

public class
InHExpMPerTest extends LaunchBrowserPage {

    @FindBy(how = How.XPATH,using = "(//*[@class='bg-white div_Shadow rounded row']//span)[1]")
    public
    WebElement Home_permission;
   @FindBy(how = How.XPATH,using = "(//*[@class='bg-white div_Shadow rounded row']//span)[9]")
    public static WebElement psychic_call;

    @Test(priority = 1)
    public void verify_InHouseExpertManager_permission() throws InterruptedException {
        user_login(InHouseExpert_name, InHouseExpert_pass);
        user_avtar.click();
        String user_name = username.getText();
        System.out.println(user_name + " this is the text which is fetched by logged user");
        Thread.sleep(6000);
        Assert.assertEquals(user_name, InHouseExpert_name);
        Thread.sleep(5000);
        System.out.println("user login : Hello test user login is successful");

        List<String> all_elements_text = new ArrayList<>();

        for (WebElement webElement : permission_list) {
            all_elements_text.add(webElement.getText());
        }

        String[] str = new String[all_elements_text.size()];

        for (int i = 0; i < all_elements_text.size(); i++) {
            str[i] = all_elements_text.get(i);
        }
        if (Arrays.toString(str).equals(Arrays.toString(in_house_expert_list)))

            System.out.println("verified given permission: " + str.length);
        else
            System.out.println("not verified given permission: " + in_house_expert_list.length);
        Assert.assertEquals(str.length, in_house_expert_list.length, "problem with admin user permission");
    }

    @Test(priority = 2)
    public void SELECT_DROPDOWN() throws InterruptedException {

        Thread.sleep(3000);
        psychic_call.click();
        // Create object of the Select class
        Select se = new Select(driver.findElement(By.xpath("//*[@id='oldSelectMenu']")));
        // select from dropdown
        se.selectByValue("10");
        se.selectByVisibleText("text");
        se.selectByIndex(10);
    }
}
