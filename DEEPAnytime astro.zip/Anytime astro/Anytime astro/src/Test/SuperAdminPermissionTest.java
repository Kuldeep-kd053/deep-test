package Test;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import static Pages.SuperAdminPermissionpage.superAdmin_name;
import static Pages.SuperAdminPermissionpage.superAdmin_pass;
import static Pages.SuperAdminPermissionpage.*;
import static Test.AdminPermissionPage.*;
import static Test.Capture_screen.take_screenshot;


public class SuperAdminPermissionTest extends LaunchBrowserPage {

    @Test(priority = 1)
    public void verify_superAdmin_permission() throws InterruptedException, IOException {
        // super admin user login
        user_login(superAdmin_name, superAdmin_pass);
        user_avtar.click();
        Thread.sleep(5000);
        //fetch username from profile
        String user_name = username.getText();
        System.out.println(user_name + " this is the username which is fetched by logged user");
        Assert.assertEquals(user_name, superAdmin_name);
        System.out.println("user login : Hello test user login is successful");
        // Store all permission list
        List<String> all_elements_text = new ArrayList<>();

        for (WebElement webElement : permission_list) {
            all_elements_text.add(webElement.getText());
        }

        String[] str1 = new String[all_elements_text.size()];

        for (int i = 0; i < all_elements_text.size(); i++) {
            str1[i] = all_elements_text.get(i);
        }
        System.out.printf(Arrays.toString(str1));

        if (str1.length == super_admin_per_list.length)
            System.out.println("permission matched: " + str1.length);

        else System.out.println("given permissions doesn't match: " + super_admin_per_list.length);

        if (Arrays.toString(str1).equals(Arrays.toString(super_admin_per_list)))
            System.out.println("verified given permission: " + str1.length);

        else
            System.out.println("not verified given permission: " + super_admin_per_list.length);
        Assert.assertEquals(str1.length, super_admin_per_list.length, "problem with admin user permission");
        //take_screenshot();
        System.out.println("Screen captured with admin login:");


    }

    @Test(priority = 2)
    public static void check_permission() throws IOException {
        AdminPermissionPage adminPermissionPage = PageFactory.initElements(driver, AdminPermissionPage.class);
        adminPermissionPage.Open_Expert_permission();
        System.out.println("permission opened");
       // take_screenshot();

    }

    @Test(priority = 3)
    public static void assign_permission() throws InterruptedException, IOException {
        AdminPermissionPage adminPermissionPage = PageFactory.initElements(driver, AdminPermissionPage.class);
        adminPermissionPage.Open_AdminUsers_permission();
        Edit_permission.click();
        Thread.sleep(5000);
        JavascriptExecutor je = (JavascriptExecutor) driver;
        je.executeScript("arguments[0].scrollIntoView(true);", ScrollToElement);
        System.out.println("The checkbox is in selected state - " + checkbox.isSelected());
        if (!checkbox.isSelected()) {
            checkbox.click();
        } else {
            System.out.println("permission already provided");
        }
        save_button.click();
        WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(40));
        w.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='alertify-notifier ajs-bottom ajs-right']//p")));
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        Assert.assertEquals(save_success_message.getText(), permission_save_success_message, "setting not saved ");
        System.out.println(" Wow! kd Rocks, Des Socks");
        //take_screenshot();

    }

}

