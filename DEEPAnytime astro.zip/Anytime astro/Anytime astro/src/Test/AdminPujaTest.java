package Test;

import Pages.PujaPurchasePage;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import java.time.Duration;


import static Pages.PujaPurchasePage.*;

public class AdminPujaTest extends LaunchBrowserPage {
    @Test(priority = 1)
    public static void create_puja() throws InterruptedException {
        PujaPurchasePage pujaPurchasePage = PageFactory.initElements(driver, PujaPurchasePage.class);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        admin_login();
        item_master_list();
        Select_Puja_Type("Individual");
        select_category("Deep Test Category");
        enter_item_master_name("tarumto");
        //add.click();
        Thread.sleep(3000);

    }
//
    @Test(priority = 2)
    public static void edit_puja_variant_test() throws InterruptedException {
        PujaPurchasePage pujaPurchasePage = PageFactory.initElements(driver, PujaPurchasePage.class);
        edit_puja_variant();

    }

//    @Test(priority = 3)
//    public static void edit_price() throws InterruptedException {
//        PujaPurchasePage pujaPurchasePage = PageFactory.initElements(driver, PujaPurchasePage.class);
//        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
//        admin_login();
//        item_master_list();
//        search_puja("Jai Bhole Puja");
//        view_edit_variant.click();
//        item_variant_price();
//    }
}

