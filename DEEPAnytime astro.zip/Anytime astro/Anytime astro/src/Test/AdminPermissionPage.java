package Test;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

import static Test.LaunchBrowserPage.driver;

public class AdminPermissionPage {

        //  [Home, Experts, Expert Profiles, Registrations, Chat Reviews, Chat Report, Attendance Report,
        //  Account deletion Request, Coupon Master, Psychic Calls, Chat Invite Summary, Customer Spam Report,
        //  Missed Chat Report, Add New Review, Language Config, Master Config, AdminUsers, Customers,
        //  Psychic Profile Review, Expert Performance, Payout, First Purchase Report, Call Chat Report,
        //  Manual Payment Deduction, Notice Board, Notice Board List, Occasion, Welcome Message Request,
        //  Deeplink, Update Bank-Detail, Bank-Detail List, Expert Insights Summary, Performance Dashboard,
        //  Expert Badge, User Permissions, Live Session Category, Live Session Type, Live Session Report,
        //  Schedule Live Session, Create Deals, Category Alias, Payments, Registration, Expert Image Review,
        //  Expert Image Updates]

public static String permission_save_success_message ="successfully saved";
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Home')]")
        public static
        WebElement Home_permission;

        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Experts')]")
        public
        WebElement Expert_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Registrations')]")
        public
        WebElement Registrations_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Chat Reviews')]")
        public
        WebElement Chat_Reviews_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Chat Report')]")
        public
        WebElement Chat_Report_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Expert Profiles')]")
        public
        WebElement Expert_Profile_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Attendance Report)]")
        public
        WebElement Attendance_Report_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Account deletion Request')]")
        public
        WebElement Account_deletion_Request_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Coupon Master')]")
        public
        WebElement Coupon_Master_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Psychic Calls')]")
        public
        WebElement Psychic_Calls_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Chat Invite Summary)]")
        public
        WebElement Chat_Invite_Summary_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Customer Spam Report')]")
        public
        WebElement Customer_Spam_Report_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Missed Chat Report')]")
        public
        WebElement Missed_Chat_Report_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Add New Review')]")
        public
        WebElement Add_New_Review_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Language Config')]")
        public
        WebElement Language_Config_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Master Config')]")
        public
        WebElement Master_Config_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'AdminUsers')]")
        public
        WebElement AdminUsers_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Customers')]")
        public
        WebElement Customers_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Psychic Profile Review')]")
        public
        WebElement Psychic_Profile_Review_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Expert Performance')]")
        public
        WebElement Expert_Performance_permission;

        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Payout')]")
        public
        WebElement Payout_permission;

        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Customer Spam Report')]")
        public
        WebElement First_Purchase_Report_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Call Chat Report')]")
        public
        WebElement Call_Chat_Report_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Notice Board List')]")
        public
        WebElement Notice_Board_List_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Notice Board')]")
        public
        WebElement Notice_Board_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Manual Payment Deduction')]")
        public
        WebElement Manual_Payment_Deduction_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Occasion')]")
        public
        WebElement Occasion_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Welcome Message Request')]")
        public
        WebElement Welcome_Message_Request_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Deeplink')]")
        public
        WebElement Deeplink_permission;

        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Update Bank-Detail')]")
        public
        WebElement Update_Bank_Detail_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Bank-Detail List')]")
        public
        WebElement Bank_Detail_List_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Expert Insights Summary')]")
        public
        WebElement Expert_Insights_Summary_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Performance Dashboard')]")
        public
        WebElement Performance_Dashboard_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Expert Badge')]")
        public
        WebElement Expert_Badge_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'User Permissions')]")
        public
        WebElement User_Permissions_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Live Session Category')]")
        public
        WebElement Live_Session_Category_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Live Session Type')]")
        public
        WebElement Live_Session_Type_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Live Session Report')]")
        public
        WebElement Live_Session_Report_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Payout')]")
        public
        WebElement Schedule_Live_Session_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Create Deals')]")
        public
        WebElement Create_Deals_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Category Alias')]")
        public
        WebElement Category_Alias_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Payments')]")
        public
        WebElement Payments_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Registration')]")
        public
        WebElement Registration_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Expert Image Review')]")
        public
        WebElement Expert_Image_Review_permission;
        @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Expert Image Updates')]")
        public
        WebElement Expert_Image_Updates_permission;

        @FindBy(how = How.XPATH, using = "//td[contains(text(),'kuldeep@innovanathinklabs.com')]/following::div//a[contains(text(),'Edit Permissions')]")
        public static WebElement Edit_permission;

        @FindBy(how = How.ID, using = "select2-Templates-result-ibka-1")
        public static WebElement Template_dropdown;

        @FindBy(how = How.XPATH, using = "(//span[@class='select2-selection__rendered'])[2]")
        public static WebElement select_temp;
        @FindBy(how = How.XPATH, using = "(//input[@class='viewpermit'])[44]")
        public static WebElement ScrollToElement;
        @FindBy(how = How.XPATH, using = "(//input[@class='viewpermit'])[48]")
        public static WebElement checkbox;
        @FindBy(how = How.ID, using = "Save")
        public static WebElement save_button;


        @FindBy(how = How.XPATH, using = "//div[@class='alertify-notifier ajs-bottom ajs-right']//p")
        public static WebElement save_success_message;

        public static void Open_home_permission() {
            Home_permission.click();
        }
        public void Open_Expert_permission() {
            Expert_permission.click();
        }

        public void Open_Registrations_permission() {
            Registrations_permission.click();
        }

        public void open_Chat_Reviews_permission() {
            Chat_Reviews_permission.click();
        }

        public void Open_Chat_Report_permission() {
            Chat_Report_permission.click();
        }

        public void Open_Expert_Profile_permission() {
            Expert_Profile_permission.click();
        }

        public void Open_Attendance_Report_permission() {
            Attendance_Report_permission.click();
        }

        public void Open_Account_deletion_Request_permission() {
            Account_deletion_Request_permission.click();
        }

        public void Open_Coupon_Master_permission() {
            Coupon_Master_permission.click();
        }

        public void Open_Psychic_Calls_permission() {
            Psychic_Calls_permission.click();
        }

        public void Open_Chat_Invite_Summary_permission() {
            Chat_Invite_Summary_permission.click();
        }

        public void Open_Customer_Spam_Report_permission() {
            Customer_Spam_Report_permission.click();
        }

        public void Open_Missed_Chat_Report_permission() {
            Missed_Chat_Report_permission.click();
        }

        public void Open_Add_New_Review_permission() {
            Add_New_Review_permission.click();
        }

        public void Open_Language_Config_permission() {
            Language_Config_permission.click();
        }

        public void Open_Master_Config_permission() {
            Master_Config_permission.click();
        }

        public void Open_AdminUsers_permission() {
            AdminUsers_permission.click();
        }

        public void Open_Customers_permission() {
            Customers_permission.click();
        }

        public void Open_Psychic_Profile_Review_permission() {
            Psychic_Profile_Review_permission.click();
        }

        public void Open_Expert_Performance_permission() {
            Expert_Performance_permission.click();
        }

        public void Open_Payout_permission() {
            Payout_permission.click();
        }

        public void Open_First_Purchase_Report_permission() {
            First_Purchase_Report_permission.click();
        }

        public void Open_Call_Chat_Report_permission() {
            Call_Chat_Report_permission.click();
        }

        public void Open_Notice_Board_List_permission() {
            Notice_Board_List_permission.click();
        }

        public void Open_Notice_Board_permission() {
            Notice_Board_permission.click();
        }

        public void Open_Manual_Payment_Deduction_permission() {
            Manual_Payment_Deduction_permission.click();
        }

        public void Open_Occasion_permission() {
            Occasion_permission.click();
        }

        public void Open_Welcome_Message_Request_permission() {
            Welcome_Message_Request_permission.click();
        }

        public void Deeplink_permission() {
            Deeplink_permission.click();
        }

        public void Open_Update_Bank_Detail_permission() {
            Update_Bank_Detail_permission.click();
        }

        public void Bank_Detail_List_permission() {
            Bank_Detail_List_permission.click();
        }

        public void Expert_Insights_Summary_permission() {
            Expert_Insights_Summary_permission.click();
        }

        public void Performance_Dashboard_permission() {
            Performance_Dashboard_permission.click();
        }

        public void Expert_Badge_permission() {
            Expert_Badge_permission.click();
        }

        public void User_Permissions_permission() {
            User_Permissions_permission.click();
        }

        public void Live_Session_Category_permission() {
            Live_Session_Category_permission.click();
        }

        public void Live_Session_Type_permission() {
            Live_Session_Type_permission.click();
        }

        public void Live_Session_Report_permission() {
            Live_Session_Report_permission.click();
        }

        public void Schedule_Live_Session_permission() {
            Schedule_Live_Session_permission.click();
        }

        public void Create_Deals_permission() {
            Create_Deals_permission.click();
        }

        public void Category_Alias_permission() {
            Category_Alias_permission.click();

        }

        public void Payments_permission() {
            Payments_permission.click();
        }

        public void Registration_permission() {
            Registration_permission.click();
        }

        public void Expert_Image_Review_permission() {
            Expert_Image_Review_permission.click();

        }

        public void Expert_Image_Updates_permission() {
            Expert_Image_Updates_permission.click();
        }

        public static void select_drp(){
                select_temp.click();
                Select drpCountry = new Select(Template_dropdown);
                drpCountry.selectByVisibleText("Campaign");
        }
    }






